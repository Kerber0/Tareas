package org.ed06.model;

/**
 * Representa una habitación de hotel con sus características y estado de disponibilidad
 */
public class Habitacion {

    private int numero;
    private TipoHabitacion tipo; // "SIMPLE", "DOBLE", "SUITE"
    private double precioBase;
    private boolean disponible;
    public enum TipoHabitacion {SIMPLE(1), DOBLE(3), SUITE(4), LITERAS(2);
        private final int maxHuespedes;
        TipoHabitacion(int maxHuespedes) {
            this.maxHuespedes = maxHuespedes;
        }
        public int getMaxHuespedes() {
            return maxHuespedes;
        }
    }

    /**
     * Constructor para crear una habitación
     * @param numero Número identificativo de la habitación
     * @param tipo Tipo de habitación
     * @param precioBase Precio base por noche
     * @throws IllegalArgumentException Si el precio es negativo
     */
    public Habitacion(int numero, String tipo, double precioBase) {
        if (precioBase < 0) {
            throw new IllegalArgumentException("El precio base no puede ser negativo");
        }
        this.numero = numero;
        this.tipo = convertirTipoHabitacion(tipo);
        this.precioBase = precioBase;
        this.disponible = true;
    }

    private TipoHabitacion convertirTipoHabitacion(String tipo) {
        try {
            return TipoHabitacion.valueOf(tipo.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Tipo de habitación no válido: " + tipo);
        }
    }

    //Getters
    public int getNumero() {
        return numero;
    }
    public TipoHabitacion getTipo() {
        return tipo;
    }
    public double getPrecioBase() {
        return precioBase;
    }
    public boolean isDisponible() {
        return disponible;
    }

    /**
     * Obtiene el número máximo por tipo
     * @return Capacidad máxima
     */
    public int obtenerNumMaxHuespedes() {
        return tipo.getMaxHuespedes();
    }

    /**
     * Reserva la habitación si esta disponible
     * @throws IllegalStateException si la habitación no esta disponible
     */
    public void reservar() {
        if (!disponible) {
            throw new IllegalStateException("Habitación #" + numero + " no está disponible");
        }
        disponible = false;
    }

    /**
     * Modifica el estado a disponible de una habitación
     */
    public void liberar() {
        disponible = true;
    }

    @Override
    public String toString() {
        return  "Habitacion:" +
                "\n -Numero= " + numero +
                "\n -Tipo= " + tipo +
                "\n -PrecioBase= " + precioBase +
                "\n -Disponible= " + disponible +
                "\n--------------------------------";
    }
}
