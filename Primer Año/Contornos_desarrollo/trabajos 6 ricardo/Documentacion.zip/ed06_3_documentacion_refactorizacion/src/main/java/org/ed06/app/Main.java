package org.ed06.app;

import org.ed06.model.*;

import java.time.*;
import java.time.format.*;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    // Definimos constantes para las diferentes opciones del menú
    private static final int REGISTRAR_HABITACION = 1;
    private static final int LISTAR_HABITACIONES_DISPONIBLES = 2;
    private static final int RESERVAR_HABITACION = 3;
    private static final int LISTAR_RESERVAS = 4;
    private static final int LISTAR_CLIENTES = 5;
    private static final int REGISTRAR_CLIENTE = 6;
    private static final int SALIR = 0;

    public static void main(String[] args) {
        // Variales locales
        String tipo;

        // Creamos un menú para el administrador con las diferentes opciones proporcionadas
        Hotel hotel = new Hotel("El mirador", "Calle Entornos de Desarrollo 6", "123456789");

        // Registramos algunas habitaciones
        hotel.registrarHabitacion("SIMPLE", 50);
        hotel.registrarHabitacion("DOBLE", 80);
        hotel.registrarHabitacion("SUITE", 120);
        hotel.registrarHabitacion("LITERAS", 200);
        hotel.registrarHabitacion("SIMPLE", 65);
        hotel.registrarHabitacion("DOBLE", 100);
        hotel.registrarHabitacion("SUITE", 150);
        hotel.registrarHabitacion("LITERAS", 250);

        // Mostramos el menú
        int opcion = -1;
        do {
            try {
                mostrarMenu();
                System.out.println("Selecione una opcion: ");
                opcion = Integer.parseInt(sc.nextLine());

                switch (opcion) {
                    case REGISTRAR_HABITACION:
                        registrarHabitacion(hotel);
                        break;
                    case LISTAR_HABITACIONES_DISPONIBLES:
                        System.out.println(hotel.listarHabitacionesDisponibles());
                        break;
                    case RESERVAR_HABITACION:
                        reservarHabitacion(hotel);
                        break;
                    case LISTAR_RESERVAS:
                        System.out.println(hotel.getReservas());
                        break;
                    case LISTAR_CLIENTES:
                        System.out.println(hotel.getClientes());
                        break;
                    case REGISTRAR_CLIENTE:
                        registrarCliente(hotel);
                        break;
                    case SALIR:
                        System.out.println("Adiós");
                        break;
                    default:
                        System.out.println("Opción no válida");
                        break;
                }
            }catch (NumberFormatException e){
                System.out.println("ERROR DATO INVALIDO");
            }
        } while (opcion != 0);
    }

    private static void registrarCliente(Hotel hotel) {
        System.out.println("--- REGISTRAR CLIENTE ---");
        System.out.println("Introduce el nombre del cliente: ");
        String nombre = sc.nextLine(); // Usar nextLine() para capturar nombres completos

        System.out.println("Introduce el DNI del cliente: ");
        String dni = sc.nextLine();

        System.out.println("Introduce el email del cliente: ");
        String email = sc.nextLine();

        System.out.println("¿Es VIP? (true/false): ");
        boolean esVip = false;
        try {
            esVip = sc.nextBoolean();
        } finally {
            sc.nextLine(); // Limpiar buffer después de nextBoolean()
        }

        hotel.registrarCliente(nombre, email, dni, esVip);
        System.out.println("Cliente registrado correctamente");
    }

    private static void reservarHabitacion(Hotel hotel) {
        System.out.println("--- RESERVAR HABITACIÓN ---");

        System.out.print("ID del cliente: ");
        int clienteId = leerEnteroPositivo();

        System.out.print("Tipo de habitación (SIMPLE, DOBLE, SUITE): ");
        String tipo = sc.nextLine().toUpperCase();

        System.out.print("Fecha de entrada (yyyy-MM-dd): ");
        LocalDate fechaEntrada = leerFecha();

        System.out.print("Fecha de salida (yyyy-MM-dd): ");
        LocalDate fechaSalida = leerFecha();

        try {
            int numeroHabitacion = hotel.reservarHabitacion(clienteId, tipo, fechaEntrada, fechaSalida);
            Habitacion habitacion = hotel.getHabitacion(numeroHabitacion);

            System.out.println("\n--- RESERVA CONFIRMADA ---");
            System.out.printf("Habitación #%d - Tipo: %s%n", habitacion.getNumero(), habitacion.getTipo());
            System.out.printf("Cliente ID: %d%n", clienteId);
            System.out.printf("Fechas: %s a %s (%d noches)%n",
                    fechaEntrada.format(DATE_FORMATTER),
                    fechaSalida.format(DATE_FORMATTER),
                    ChronoUnit.DAYS.between(fechaEntrada, fechaSalida));
        } catch (Exception e) {
            System.out.println("Error al realizar la reserva: " + e.getMessage());
        }
    }

    private static int leerEnteroPositivo() {
        while (true) {
            try {
                int valor = Integer.parseInt(sc.nextLine());
                if (valor > 0) return valor;
                System.out.print("Ingrese un valor positivo: ");
            } catch (NumberFormatException e) {
                System.out.print("Entrada inválida. Ingrese un número: ");
            }
        }
    }

    private static LocalDate leerFecha() {
        while (true) {
            try {
                return LocalDate.parse(sc.nextLine(), DATE_FORMATTER);
            } catch (DateTimeParseException e) {
                System.out.print("Formato inválido. Use yyyy-MM-dd: ");
            }
        }
    }

    private static void registrarHabitacion(Hotel hotel) {
        String tipo;
        System.out.println("Introduce el tipo de habitación (SIMPLE, DOBLE, SUITE): ");
        tipo = sc.nextLine();
        System.out.println("Introduce el precio base de la habitación: ");
        double precioBase = sc.nextDouble();
        sc.nextLine();
        hotel.registrarHabitacion(tipo, precioBase);
        System.out.println("Registrado correctamente");
    }

    private static void mostrarMenu() {
        System.out.println("Menú:");
        System.out.println("1. Registrar habitación");
        System.out.println("2. Listar habitaciones disponibles");
        System.out.println("3. Reservar habitación");
        System.out.println("4. Listar reservas");
        System.out.println("5. Listar clientes");
        System.out.println("6. Registrar cliente");
        System.out.println("0. Salir");
    }
}