package org.ed06.model;

/**
 * Representa un cliente del sistema con sus datos y su estado VIP
 * Proporciona validaciones para la entrada de datos
 */
public class Cliente {
    public int id;
    public String nombre;
    public String dni;
    public String email;
    public boolean esVip;

    /**
     * Constructor para crear un nuevo cliente con validacion de datos
     * @param id Identificador único del cliente
     * @param nombre Nombre completo del cliente
     * @param dni DNI del cliente con formato español
     * @param email Email del cliente con formato valido
     * @param esVip Indica si es cliente es VIP o si no es VIP
     */
    public Cliente(int id, String nombre, String dni, String email, boolean esVip) {
        this.id = id;
        this.nombre = validarNombre(nombre);
        this.dni = validarDni(dni);
        this.email = validarEmail(email);
        this.esVip = esVip;
    }

    //Getters
    public int getId() {
        return id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getDni() {
        return dni;
    }
    public String getEmail() {
        return email;
    }
    public boolean isEsVip() {
        return esVip;
    }

    /**
     * Valída que el nombre cumpla con lo mínimo
     * @param nombre Nombre a validar
     * @return El nombre válido
     * @throws IllegalArgumentException si el nombre es nulo, vacio o menor de 3 caracteres
     */
    private String validarNombre(String nombre) {
        // Comprobamos que el nombre no sea nulo, esté vacio y tenga al menos 3 caracteres eliminando espacios inciales y finales
        if (nombre == null || nombre.trim().length() < 3) {
            throw new IllegalArgumentException("El nombre no es válido");
        }
        return nombre;
    }

    /**
     * Valida el formato del email
     * @param email Email a validar
     * @return El email validado
     * @throws IllegalArgumentException si el email no cumple con el formato
     */
    private String validarEmail(String email) {
        if (!email.matches("[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}")) {
            throw new IllegalArgumentException("El email no es válido");
        }
        return email;
    }

    /**
     * Valída el formato del DNI
     * @param dni DNI a validar
     * @return El DNI valído
     * @throws IllegalArgumentException si el DNI no cumple con el formato
     */
    public String validarDni(String dni) {
        if (!dni.matches("[0-9]{7}[A-Z]")) {
            throw new IllegalArgumentException("El DNI no es válido");
        }
        return dni;
    }

    @Override
    public String toString() {
        return "Cliente: " +
                "\n -id= " + id +
                "\n -nombre= " + nombre +
                "\n -dni=" + dni +
                "\n -email='" + email + '\'' +
                "\n -Vip=" + esVip +
                "\n--------------------------------";
    }
}