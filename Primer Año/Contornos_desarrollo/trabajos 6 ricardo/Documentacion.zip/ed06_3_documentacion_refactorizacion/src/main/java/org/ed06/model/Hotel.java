package org.ed06.model;
import java.time.LocalDate;
import java.util.*;

/**
 * Representa un hotel con sus habitaciones, clientes y sistema de reservas
 * Gestiona la disponibilidad de habitaciones y las reservas de clientes
 */
public class Hotel {

    private String nombre;
    private String direccion;
    private String telefono;

    private final Map<Integer,Cliente> clientes = new HashMap<>();
    private final List<Habitacion> habitaciones = new ArrayList<>();
    private final Map<Integer,List<Reserva>> reservasPorHabitacion = new HashMap<>();

    /**
     * Constructor para crear un nuevo hotel
     * @param nombre Nombre del hotel
     * @param direccion Dirección física del hotel
     * @param telefono Número de contacto del hotel
     */
    public Hotel(String nombre, String direccion, String telefono) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    //Getters
    public String getNombre() {
        return nombre;
    }
    public String getDireccion() {
        return direccion;
    }
    public String getTelefono() {
        return telefono;
    }

    /**
     * Registra una nueva habitación en el hotel
     * @param tipo Tipo de habitación
     * @param precioBase Precio base por noche
     * @return La habitación creada
     */
    public Habitacion registrarHabitacion(String tipo, double precioBase) {
        Habitacion habitacion = new Habitacion(habitaciones.size() + 1, tipo, precioBase);
        habitaciones.add(habitacion);
        reservasPorHabitacion.put(habitacion.getNumero(), new ArrayList<>());
        return habitacion;
    }

    /**
     * Registrar múltiples habitaciones en el hotel
     * @param tipos Lista de tipos de habitaciones
     * @param preciosBase Lista de los precios bases correspondientes
     * @throws IllegalArgumentException si las listas no concuerdan
     */
    public void registrarHabitaciones(List<String> tipos, List<Double> preciosBase) {
        if (tipos.size() != preciosBase.size()) {
            throw new IllegalArgumentException("Las listas de tipos y precios deben tener el mismo tamaño");
        }
        for (int i = 0; i < tipos.size(); i++) {
            registrarHabitacion(tipos.get(i), preciosBase.get(i));
        }
    }

    /**
     * Obtiene una lista de las habitaciones disponibles
     * @return Lista de habitaciones disponibles
     */
    public List<Habitacion> listarHabitacionesDisponibles() {
        List<Habitacion> disponibles = new ArrayList<>();
        for(Habitacion habitacion : habitaciones) {
            if(habitacion.isDisponible()) {
                disponibles.add(habitacion);
            }
        }
        return disponibles;
    }

    /**
     * Obtiene una habitación por su número
     * @param numero Número de la habitación
     * @return La habitación encontrada o null si no existe
     */
    public Habitacion getHabitacion(int numero) {
        for(Habitacion habitacion : habitaciones) {
            if(habitacion.getNumero() == numero) {
                return habitacion;
            }
        }
        return null;
    }

    /**
     * Realiza una reserva de habitación
     * @param clienteId ID del cliente que realiza la reserva
     * @param tipo Tipo de habitación solicitada
     * @param fechaEntrada Fecha de entrada
     * @param fechaSalida Fecha de salida
     * @return Resultado de la reserva
     * @throws IllegalArgumentException si las fechas son invalidas
     */
    public int reservarHabitacion(int clienteId, String tipo, LocalDate fechaEntrada, LocalDate fechaSalida) {
        if (habitaciones.isEmpty()) {
            throw new IllegalStateException("No hay habitaciones en el hotel");
        }

        Cliente cliente = clientes.get(clienteId);
        if (cliente == null) {
            throw new IllegalArgumentException("No existe el cliente con id " + clienteId);
        }

        if (fechaEntrada.isAfter(fechaSalida)) {
            throw new IllegalArgumentException("La fecha de entrada no puede ser posterior a la fecha de salida");
        }

        for (Habitacion habitacion : habitaciones) {
            if (habitacion.getTipo().equals(tipo) && habitacion.isDisponible()) {
                return procesarReserva(cliente, habitacion, fechaEntrada, fechaSalida);
            }
        }

        throw new IllegalStateException("No hay habitaciones disponibles del tipo " + tipo);
    }

    private int procesarReserva(Cliente cliente, Habitacion habitacion, LocalDate fechaEntrada, LocalDate fechaSalida) {
        verificarPromocionVIP(cliente);

        Reserva reserva = new Reserva(generarNuevoIdReserva(), habitacion, cliente, fechaEntrada, fechaSalida);
        reservasPorHabitacion.get(habitacion.getNumero()).add(reserva);
        habitacion.reservar();

        return habitacion.getNumero();
    }

    private void verificarPromocionVIP(Cliente cliente) {
        long numReservas = contarReservasUltimoAnio(cliente);
        if (numReservas > 3 && !cliente.isEsVip()) {
            cliente.esVip = true;
        }
    }

    private long contarReservasUltimoAnio(Cliente cliente) {
        return reservasPorHabitacion.values().stream()
                .flatMap(List::stream)
                .filter(r -> r.getCliente().equals(cliente))
                .filter(r -> r.getFechaInicio().isAfter(LocalDate.now().minusYears(1)))
                .count();
    }

    private int generarNuevoIdReserva() {
        return reservasPorHabitacion.values().stream()
                .mapToInt(List::size)
                .sum() + 1;
    }

    /**
     * Obtiene todas las reservas del hotel
     * @return Mapa de reservas por habitacion
     */
    public Map<Integer, List<Reserva>> getReservas() {
        return Collections.unmodifiableMap(reservasPorHabitacion);
    }

    /**
     * Obtiene todos los clientes registrados en el hotel
     * @return Lista de clientes
     */
    public Collection<Cliente> getClientes() {
        return Collections.unmodifiableCollection(clientes.values());
    }

    /**
     * Registra un nuevo cliente en el hotel
     * @param nombre Nombre completo del cliente
     * @param email Email del cliente
     * @param dni DNI del cliente
     * @param esVip Indica si el cliente es VIP o no es VIP
     * @return EL cliente registrado
     */
    public Cliente registrarCliente(String nombre, String email, String dni, boolean esVip) {
        Cliente cliente = new Cliente(generarNuevoIdCliente(), nombre, dni, email, esVip);
        clientes.put(cliente.getId(), cliente);
        return cliente;
    }

    private int generarNuevoIdCliente() {
        return clientes.isEmpty() ? 1 : Collections.max(clientes.keySet()) + 1;
    }
}
