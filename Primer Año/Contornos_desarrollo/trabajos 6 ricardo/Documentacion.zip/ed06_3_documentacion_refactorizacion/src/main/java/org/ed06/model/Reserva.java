package org.ed06.model;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Representa una reserva de hotel realizada por un cliente
 * Gestiona los datos de la reserva y el cálculo del precio final
 */
public class Reserva {

    private static final double DESCUENTO_VIP = 0.10; // 10%
    private static final double DESCUENTO_LARGA_ESTANCIA = 0.05; // 5%
    private static final int DIAS_ESTANCIA_LARGA = 7;

    private int id;
    private Habitacion habitacion;
    private Cliente cliente;
    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private double precioTotal;

    /**
     * Constructor para crear una nueva reserva
     * @param id Identificador único de la reserva
     * @param habitacion Habitación reservada
     * @param cliente Cliente que realiza la reserva
     * @param fechaInicio Fecha de inicio de la reserva
     * @param fechaFin Fecha de fin de la reserva
     * @throws IllegalArgumentException Si las fechas son invalidas
     */
    public Reserva(int id, Habitacion habitacion, Cliente cliente, LocalDate fechaInicio, LocalDate fechaFin) {
        if (fechaInicio.isAfter(fechaFin)) {
            throw new IllegalArgumentException("La fecha de inicio no puede ser posterior a la fecha de fin");
        }
        if (habitacion == null || cliente == null) {
            throw new IllegalArgumentException("Habitación y cliente no pueden ser nulos");
        }
        this.id = id;
        this.habitacion = habitacion;
        this.cliente = cliente;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.precioTotal = calcularPrecioFinal();
    }

    //Getters
    public int getId() {
        return id;
    }
    public Habitacion getHabitacion() {
        return habitacion;
    }
    public Cliente getCliente() {
        return cliente;
    }
    public LocalDate getFechaInicio() {
        return fechaInicio;
    }
    public LocalDate getFechaFin() {
        return fechaFin;
    }
    public double getPrecioTotal() {
        return precioTotal;
    }

    /**
     * Calcula el precio total de la reserva aplicando los descuentos dependiendo del caso del cliente
     * - Precio base * número de noches
     * - 10% en caso si el cliente es VIP
     * - 5% adicional si la estancia es mayor a 7 días
     * @return Precio total con descuentos correspondientes
     */
    public double calcularPrecioFinal() {
        long noches = ChronoUnit.DAYS.between(fechaInicio, fechaFin);
        double precioBase = habitacion.getPrecioBase() * noches;
        double precioConDescuentos = precioBase;
        if (cliente.isEsVip()) {
            precioConDescuentos *= (1 - DESCUENTO_VIP);
        }
        if (noches > DIAS_ESTANCIA_LARGA) {
            precioConDescuentos *= (1 - DESCUENTO_LARGA_ESTANCIA);
        }
        return precioConDescuentos;
    }

    /**
     * Obtiene el número de noches de la reserva
     * @return Número de noches
     * @return
     */
    public long getNumeroNoches() {
        return ChronoUnit.DAYS.between(fechaInicio,fechaFin);
    }


}
