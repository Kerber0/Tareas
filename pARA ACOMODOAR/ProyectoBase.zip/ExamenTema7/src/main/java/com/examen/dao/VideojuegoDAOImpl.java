package com.examen.dao;

import com.examen.model.Videojuego;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class VideojuegoDAOImpl implements VideojuegoDAO {
    private final Connection conn;

    public VideojuegoDAOImpl() throws SQLException {
        this.conn = com.examen.DatabaseFactory.getConnection();
    }

    public VideojuegoDAOImpl(Connection conn) {
        this.conn = conn;
    }

    /**
     * Método para validar los datos de un videojuego.
     * Si no cumple alguna de las validaciones, lanzará una IllegalArgumentException.
     * @param v Videojuego a validar
     */
    private void validarDatos(Videojuego v) {
        // Validaciones de los datos del videojuego
        // Este método es opcional pero recomendable para evitar duplicar código
    }

    /**
     * Método para crear un nuevo videojuego.
     * Si no cumple alguna de las validaciones, lanzará una IllegalArgumentException.
     * @param v Videojuego a crear
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    @Override
    public void crear(Videojuego v) throws SQLException {
        // TODO: Implementar la creación de un videojuego
    }

    /**
     * Método para buscar un videojuego por su ID.
     * @param id ID del videojuego a buscar
     * @return El videojuego encontrado o null si no existe
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    @Override
    public Videojuego buscarPorId(int id) throws SQLException {
        // TODO: Implementar la búsqueda de un videojuego por ID
        return null;
    }

    /**
     * Método para listar todos los videojuegos.
     * @return Lista de videojuegos
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    @Override
    public List<Videojuego> listarTodos() throws SQLException {
        // TODO: Implementar la lista de todos los videojuegos
        return List.of();
    }

    /**
     * Método para actualizar un videojuego.
     * Si no cumple alguna de las validaciones, lanzará una IllegalArgumentException.
     * @param v Videojuego a actualizar
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    @Override
    public void actualizar(Videojuego v) throws SQLException {
        // TODO: Implementar la actualización de un videojuego
    }

    /**
     * Método para borrar un videojuego por su ID.
     * @param id ID del videojuego a borrar
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    @Override
    public void borrar(int id) throws SQLException {
        // TODO: Implementar la eliminación de un videojuego
    }

    /**
     * Método para calcular el precio medio de los videojuegos por plataforma.
     * @return Un mapa donde la clave es el nombre de la plataforma y el valor es el precio medio.
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    @Override
    public Map<String, Double> precioMedioPorPlataforma() throws SQLException {
        // TODO: Implementar el cálculo del precio medio por plataforma
        return Map.of();
    }

    /**
     * Método para registrar una venta de un videojuego.
     * Este método debería actualizar el stock del videojuego y registrar la venta.
     *
     * @param juegoId ID del videojuego vendido
     * @throws SQLException Si ocurre un error al acceder a la base de datos
     */
    @Override
    public void registrarVenta(int juegoId) throws SQLException {
        // TODO: Implementar el registro de una venta
    }
}